let searchBox = document.getElementById('searchEngine');
let movieContainer = document.getElementById("movie-data");

let voiceSearch=document.getElementById('voiceSearchBtn')
const speech=window.SpeechRecognition ||  window.webkitSpeechRecognition
const recognition=new speech()
recognition.lang="eng-US"

voiceSearch.addEventListener('click',(event)=>{
  // event.preventDefault()
  recognition.start()
})

recognition.onresult=(event)=>{
  const voiceSearch=event.results[0][0].transcript
  voiceSearch.value=voiceSearch
  fetchMovies(voiceSearch)
}

searchBox.addEventListener('input', (event) => {
   let searchIn = searchBox.value.trim();
    
    if (searchIn) {
        const imdbAPI = `http://www.omdbapi.com/?s=${searchIn}&apikey=f056e2f7`;

       fetchMovies(imdbAPI);
   } else {
       movieContainer.innerHTML = '';
   }
});


let fetchMovies = async (url) => {
    try {

        let response = await fetch(url);
        let data = await response.json();
        console.log("data", data);
        if(data.Response==="True"){

document.getElementById('container').style.display="none"
}else{
    document.getElementById('container').style.display="block"
}
        // Clear the previous results
        movieContainer.innerHTML = '';



        if (data.Search)  {
            let movieList = `<div class="row">`;
            data.Search.forEach((value) => {
                let movieCard = `
                    <div class="card col-12 col-sm-6 col-md-3 gap-2 movie-card">
                        <img src="${value.Poster}" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h5 class="card-title">${value.Title}</h5>
                            <p>${value.Year}</p>
                        </div>
                    </div>`;
                movieList += movieCard;
            });
            movieList += `</div>`;

            movieContainer.innerHTML = movieList;
        } else {
            movieContainer.innerHTML = '<p>No movies found.</p>';
        }
    } catch (err) {
        console.log("err", err);
    }
};
